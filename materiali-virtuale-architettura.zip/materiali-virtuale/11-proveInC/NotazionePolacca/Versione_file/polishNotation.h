typedef char* inType;

int eval(inType expr);
