//  main.c
#include <stdio.h>

#include "somma.h"

int main() {
  printf("somma: %d\n",somma(5,3));
  return 0;
}

