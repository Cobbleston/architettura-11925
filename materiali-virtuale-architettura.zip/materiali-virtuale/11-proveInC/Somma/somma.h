// somma.h
int somma(int i,int j);
