// somma.c
#include "somma.h"
int somma(int i,int j){
  return i+j;
}

