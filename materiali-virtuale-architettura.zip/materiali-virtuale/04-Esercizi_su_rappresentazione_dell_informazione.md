## Esercizio 1

Si consideri il numero decimale 35 (senza segno).
Lo si converta in binario, poi dal binario in esadecimale, e dall'esadecimale di nuovo in decimale.

## Esercizio 2

Si consideri il numero decimale -13.
Lo si converta in binario (su 8 bit) con le codifiche:
- modulo e segno
- complemento a 1
- complemento a 2
- eccesso 128

## Esercizio 3

Si converta il numero 0.3 in notazione floating point in base 2
normalizzata (usando il complemento a 2 su 8 bit sia per la mantissa
che per l'esponente).
